import { Category, Service } from '@/types/services';

export const categories: Category[] = [
  {
    id: 'all',
    name: 'الكل',
    icon: 'Grid3x3',
  },
  {
    id: 'subscriptions',
    name: 'الاشتراكات',
    icon: 'CreditCard',
  },
];

export const services: Service[] = [
  {
    id: 'gemini-12',
    name: 'Gemini Advanced - سنة',
    category: 'subscriptions',
    subcategory: 'ai',
    icon: 'Sparkles',
    duration: '12 شهر',
    price: 15,
    available: 45,
    options: [
      {
        id: 'student-bypass',
        type: 'student_verification',
        name: 'تخطي تحقق الطالب',
        description: 'تفعيل عبر رابط التحقق الطلابي - يتم إرسال رابط التحقق الخاص بك وسيتم التحقق خلال دقائق',
        requirements: ['رابط التحقق'],
        estimatedTime: '2-5 دقائق',
      },
      {
        id: 'full-activation',
        type: 'full_activation',
        name: 'تفعيل اشتراك كامل',
        description: 'تفعيل الاشتراك بالكامل على حسابك - يتطلب إيميل وباسورد الحساب للتحقق من وجود العرض',
        requirements: ['إيميل', 'باسورد'],
        estimatedTime: '5-10 دقائق',
      },
    ],
  },
];
