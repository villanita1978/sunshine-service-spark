export type ServiceType = 'full_activation' | 'student_verification';

export type VerificationStatus = 'pending' | 'success' | 'failed' | null;

export interface ServiceOption {
  id: string;
  type: ServiceType;
  name: string;
  description: string;
  requirements: string[];
  estimatedTime?: string;
}

export interface Service {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  icon: string;
  duration: string;
  price: number;
  available: number;
  options: ServiceOption[];
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  subcategories?: Subcategory[];
}

export interface Subcategory {
  id: string;
  name: string;
}

export interface OrderRequest {
  serviceId: string;
  optionId: string;
  email?: string;
  password?: string;
  verificationLink?: string;
  quantity: number;
}

export interface Order {
  id: string;
  serviceId: string;
  serviceName: string;
  optionType: ServiceType;
  status: VerificationStatus;
  createdAt: Date;
  email?: string;
}
