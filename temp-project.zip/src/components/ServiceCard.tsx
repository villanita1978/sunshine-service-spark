import { Service } from '@/types/services';
import { icons, LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  service: Service;
  onClick: (service: Service) => void;
}

const ServiceCard = ({ service, onClick }: ServiceCardProps) => {
  const getIcon = (iconName: string): LucideIcon => {
    return icons[iconName as keyof typeof icons] || icons.Box;
  };

  const Icon = getIcon(service.icon);

  return (
    <div
      onClick={() => onClick(service)}
      className="card-simple p-4 cursor-pointer hover:shadow-md transition-all duration-200"
    >
      {/* Header */}
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground truncate">{service.name}</h3>
          <p className="text-sm text-muted-foreground">{service.duration}</p>
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-border">
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold text-primary">${service.price}</span>
          <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded">
            متوفر: {service.available}
          </span>
        </div>
        <button className="btn-primary px-3 py-1.5 text-sm">
          اختر
        </button>
      </div>
    </div>
  );
};

export default ServiceCard;
