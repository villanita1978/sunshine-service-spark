import { useState } from 'react';
import { Service, ServiceOption, VerificationStatus } from '@/types/services';
import { Mail, Lock, Link, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface ServiceModalProps {
  service: Service | null;
  isOpen: boolean;
  onClose: () => void;
}

const ServiceModal = ({ service, isOpen, onClose }: ServiceModalProps) => {
  const [selectedOption, setSelectedOption] = useState<ServiceOption | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [verificationLink, setVerificationLink] = useState('');
  const [status, setStatus] = useState<VerificationStatus>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!selectedOption) return;

    setIsSubmitting(true);
    
    if (selectedOption.type === 'student_verification') {
      setStatus('pending');
      setTimeout(() => {
        const success = Math.random() > 0.3;
        setStatus(success ? 'success' : 'failed');
        setIsSubmitting(false);
      }, 3000);
    } else {
      setTimeout(() => {
        setStatus('success');
        setIsSubmitting(false);
      }, 2000);
    }
  };

  const handleClose = () => {
    setSelectedOption(null);
    setEmail('');
    setPassword('');
    setVerificationLink('');
    setStatus(null);
    setIsSubmitting(false);
    onClose();
  };

  const renderStatus = () => {
    if (!status) return null;

    const statusConfig = {
      pending: {
        icon: <Loader2 className="w-6 h-6 animate-spin" />,
        title: 'جاري التحقق...',
        description: 'يرجى الانتظار من 2-5 دقائق',
        className: 'status-pending',
      },
      success: {
        icon: <CheckCircle className="w-6 h-6" />,
        title: 'تم التحقق بنجاح!',
        description: 'تم تفعيل الخدمة على حسابك',
        className: 'status-success',
      },
      failed: {
        icon: <XCircle className="w-6 h-6" />,
        title: 'فشل التحقق',
        description: 'يرجى المحاولة مرة أخرى',
        className: 'status-failed',
      },
    };

    const config = statusConfig[status];

    return (
      <div className={`p-4 rounded-lg text-center ${config.className}`}>
        <div className="flex justify-center mb-2">{config.icon}</div>
        <h4 className="font-semibold">{config.title}</h4>
        <p className="text-sm">{config.description}</p>
      </div>
    );
  };

  if (!service) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="card-simple max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">{service.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* Service Info */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-secondary">
            <div>
              <p className="text-xs text-muted-foreground">السعر</p>
              <p className="text-xl font-bold text-primary">${service.price}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">المدة</p>
              <p className="font-semibold">{service.duration}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">متوفر</p>
              <p className="font-semibold text-success">{service.available}</p>
            </div>
          </div>

          {/* Options */}
          {!status && (
            <>
              <div>
                <h4 className="font-semibold mb-2 text-sm">اختر نوع التفعيل</h4>
                <div className="space-y-2">
                  {service.options.map((option) => (
                    <div
                      key={option.id}
                      onClick={() => setSelectedOption(option)}
                      className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                        selectedOption?.id === option.id
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <h5 className="font-medium text-sm">{option.name}</h5>
                      <p className="text-xs text-muted-foreground">{option.description}</p>
                      {option.estimatedTime && (
                        <span className="inline-block mt-1 text-xs text-warning bg-warning/10 px-2 py-0.5 rounded">
                          {option.estimatedTime}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Form */}
              {selectedOption && (
                <div className="space-y-3">
                  {selectedOption.type === 'full_activation' && (
                    <>
                      <div>
                        <label className="block text-sm font-medium mb-1">
                          <Mail className="w-4 h-4 inline ml-1" />
                          البريد الإلكتروني
                        </label>
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="example@email.com"
                          className="input-field w-full"
                          dir="ltr"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">
                          <Lock className="w-4 h-4 inline ml-1" />
                          كلمة المرور
                        </label>
                        <input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="••••••••"
                          className="input-field w-full"
                          dir="ltr"
                        />
                      </div>
                    </>
                  )}

                  {selectedOption.type === 'student_verification' && (
                    <div>
                      <label className="block text-sm font-medium mb-1">
                        <Link className="w-4 h-4 inline ml-1" />
                        رابط التحقق
                      </label>
                      <input
                        type="url"
                        value={verificationLink}
                        onChange={(e) => setVerificationLink(e.target.value)}
                        placeholder="https://..."
                        className="input-field w-full"
                        dir="ltr"
                      />
                    </div>
                  )}

                  <button
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                    className="btn-primary w-full py-2.5 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        جاري المعالجة...
                      </>
                    ) : (
                      'تأكيد الطلب'
                    )}
                  </button>
                </div>
              )}
            </>
          )}

          {/* Status Display */}
          {renderStatus()}

          {status && (
            <button
              onClick={handleClose}
              className="w-full py-2 rounded-lg font-medium bg-secondary hover:bg-muted transition-colors"
            >
              إغلاق
            </button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ServiceModal;
